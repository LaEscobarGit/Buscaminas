package buscaminas;

public class MineSweeperConstants {
    public static final int ROWS = 10;
    public static final int COLS = 10;
}
