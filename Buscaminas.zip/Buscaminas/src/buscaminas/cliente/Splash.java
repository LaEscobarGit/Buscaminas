package buscaminas.cliente;

import buscaminas.recursos.Fondo;
import buscaminas.recursos.audio.*;
import java.awt.*;
import javax.swing.*;

public class Splash extends JFrame {

    private float opacityLevel = 1f;
    private Timer fadeTimer;
    private JProgressBar barra;
    private Menu menu;

    public Splash() {

        setSize(1024, 615);
        setUndecorated(true);
        setLocationRelativeTo(null);
        setAlwaysOnTop(true);

        Fondo panelFondo = new Fondo("/buscaminas/recursos/imagenes/splash.png");
        panelFondo.setLayout(null);
        setContentPane(panelFondo);

        barra = new JProgressBar();
        barra.setMinimum(0);
        barra.setMaximum(100);
        barra.setValue(0);
        barra.setStringPainted(true);

        barra.setBounds(262, 500, 500, 25);
        panelFondo.add(barra);
        
        iniciarCarga();
    }

    private void iniciarCarga() {
        menu = new Menu();
        menu.setLocationRelativeTo(null);
        menu.setVisible(true);
        
        AudioManager.playSonido("/buscaminas/recursos/audio/boot.wav");
        
        Timer loadTimer = new Timer(50, e -> {
            int val = barra.getValue();

            if (val < 100) {
                barra.setValue(val + 1);
            } else {
                ((Timer) e.getSource()).stop();
                startFade();
            }
        });

        loadTimer.start();
    }

    private void startFade() {

        fadeTimer = new Timer(40, e -> {
            opacityLevel -= 0.05f;

            if (opacityLevel <= 0) {
                opacityLevel = 0;
                fadeTimer.stop();

                setAlwaysOnTop(false);

                dispose();  

                menu.toFront();
                menu.requestFocus();
                AudioManager.playMusica("/buscaminas/recursos/audio/menu.wav");
                return;
            }

            setOpacity(opacityLevel);
        });

        fadeTimer.start();
    }
}
