package buscaminas.cliente;
import buscaminas.recursos.audio.AudioManager;
import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class VolumenFrame extends javax.swing.JFrame implements ChangeListener{
    public VolumenFrame() {
        initComponents();
        
        int valMusica = (int) (100*AudioManager.getMusicVol());
        int valSonido = (int) (100*AudioManager.getSonidoVol());
        musicLabel.setText(String.valueOf(valMusica));
        sonidoLabel.setText(String.valueOf(valSonido));
        sliderMusic.setValue(valMusica);
        sliderSonido.setValue(valSonido);
        sliderMusic.addChangeListener(this);
        sliderSonido.addChangeListener(this);
        //sliderMusic.addActionListener(e -> AudioManager.play("/buscaminas/recursos/audio/slider.wav"));
        //sliderSonido.addActionListener(e -> AudioManager.play("/buscaminas/recursos/audio/slider.wav"));
        
        AudioManager.agregarSonidoBotones(this, "/buscaminas/recursos/audio/click1.wav","/buscaminas/recursos/audio/hover.wav");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Opciones");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        sliderMusic = new javax.swing.JSlider();
        sliderSonido = new javax.swing.JSlider();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        musicLabel = new javax.swing.JLabel();
        sonidoLabel = new javax.swing.JLabel();
        cancelarBot = new javax.swing.JButton();
        aceptarBot = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        sliderMusic.setMajorTickSpacing(50);
        sliderMusic.setValue(100);

        sliderSonido.setMajorTickSpacing(50);
        sliderSonido.setValue(100);

        jLabel1.setFont(new java.awt.Font("Zpix", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(83, 40, 206));
        jLabel1.setText("Musica");

        jLabel2.setFont(new java.awt.Font("Zpix", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(83, 40, 206));
        jLabel2.setText("Sonido");

        musicLabel.setFont(new java.awt.Font("Zpix", 1, 18)); // NOI18N
        musicLabel.setForeground(new java.awt.Color(83, 40, 206));
        musicLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        musicLabel.setText("80");

        sonidoLabel.setFont(new java.awt.Font("Zpix", 1, 18)); // NOI18N
        sonidoLabel.setForeground(new java.awt.Color(83, 40, 206));
        sonidoLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        sonidoLabel.setText("100");

        cancelarBot.setFont(new java.awt.Font("Zpix", 0, 12)); // NOI18N
        cancelarBot.setForeground(new java.awt.Color(83, 40, 206));
        cancelarBot.setText("Cancelar");
        cancelarBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarBotActionPerformed(evt);
            }
        });

        aceptarBot.setFont(new java.awt.Font("Zpix", 0, 12)); // NOI18N
        aceptarBot.setForeground(new java.awt.Color(83, 40, 206));
        aceptarBot.setText("Aceptar");
        aceptarBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aceptarBotActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(cancelarBot)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(aceptarBot))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(musicLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(sonidoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(18, 18, 18)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(sliderSonido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(sliderMusic, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(69, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(63, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(musicLabel)
                    .addComponent(sliderMusic, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(sonidoLabel))
                    .addComponent(sliderSonido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cancelarBot, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(aceptarBot, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(72, 72, 72))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cancelarBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarBotActionPerformed
        dispose();
    }//GEN-LAST:event_cancelarBotActionPerformed

    private void aceptarBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aceptarBotActionPerformed
        AudioManager.setSonidoVol(sliderSonido.getValue()/100f);
        AudioManager.setMusicaVol(sliderMusic.getValue()/100f);
        dispose();
    }//GEN-LAST:event_aceptarBotActionPerformed
    
    @Override
    public void stateChanged(ChangeEvent e) {
        musicLabel.setText(String.valueOf(sliderMusic.getValue()));
        sonidoLabel.setText(String.valueOf(sliderSonido.getValue()));
    }
    
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    FlatLightLaf.registerCustomDefaultsSource( "Buscaminas.recursos" );
                    UIManager.setLookAndFeel( new FlatLightLaf() );
                } catch( Exception ex ) {
                    System.err.println( "Failed to initialize Look and Feel" );
                }
                new VolumenFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton aceptarBot;
    private javax.swing.JButton cancelarBot;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel musicLabel;
    private javax.swing.JSlider sliderMusic;
    private javax.swing.JSlider sliderSonido;
    private javax.swing.JLabel sonidoLabel;
    // End of variables declaration//GEN-END:variables
}
