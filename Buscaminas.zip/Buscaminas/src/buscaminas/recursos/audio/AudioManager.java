package buscaminas.recursos.audio;
import java.awt.Container;
import java.io.IOException;
import javax.sound.sampled.*;

public class AudioManager {
    private static Clip musicClip;
    private static float musicVol = 0.8f;
    private static float sfxVol = 1f;

    public static float getMusicVol(){
        return musicVol;
    }
    public static float getSonidoVol(){
        return sfxVol;
    }
    
    // cargar
    public static Clip cargarClip(String ruta) {
        try {
            AudioInputStream ais = AudioSystem.getAudioInputStream(
                AudioManager.class.getResource(ruta)
            );
            Clip clip = AudioSystem.getClip();
            clip.open(ais);
            return clip;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // musiquita
    public static void playMusica(String ruta) {
        if (musicClip != null && musicClip.isRunning()) musicClip.stop();
        musicClip = cargarClip(ruta);
        if (musicClip != null) {
            setVolume(musicClip, musicVol);
            musicClip.loop(Clip.LOOP_CONTINUOUSLY);
            musicClip.start();
        }
    }
    
    public static void parar() {
        if (musicClip != null && musicClip.isRunning()) {
            musicClip.stop();
            musicClip.close();
        }
    }

    public static void setMusicaVol(float vol) {
        musicVol = vol;
        setVolume(musicClip, vol);
    }

    // sonidos
    public static void playSonido(String ruta) {
        Clip sfx = cargarClip(ruta);
        if (sfx != null) {
            setVolume(sfx, sfxVol);
            sfx.start();
        }
    }

    public static void setSonidoVol(float vol) {
        sfxVol = vol;
    }

    // control de volumen
    private static void setVolume(Clip clip, float volume) {
        if (clip == null) return;
        if (!clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) return;

        FloatControl gain = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);

        float min = gain.getMinimum();
        float max = gain.getMaximum();

        float dB = min + (max - min) * volume;
        gain.setValue(dB);
    }
    
    //para darle a todos los botones
    public static void agregarSonidoBotones(Container contenedor, String audioClick, String audioHover){
        for (java.awt.Component c : contenedor.getComponents()) {
            if (c instanceof javax.swing.AbstractButton boton) {
                if (audioClick != null) {
                    boton.addActionListener(e -> AudioManager.playSonido(audioClick));
                }
                if (audioHover != null) {
                    boton.addMouseListener(new java.awt.event.MouseAdapter() {
                        @Override
                        public void mouseEntered(java.awt.event.MouseEvent e) {
                            AudioManager.playSonido(audioHover);
                        }
                    });
                }
            }
            if (c instanceof java.awt.Container sub) {
                agregarSonidoBotones(sub, audioClick, audioHover);
            }
        }
    }
}
