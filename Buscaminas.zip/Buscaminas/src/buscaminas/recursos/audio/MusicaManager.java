package buscaminas.recursos.audio;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;

public class MusicaManager {
    private static Clip musicClip;
    private static FloatControl gainControl;
    private static float volumen = 1.0f;
    private static boolean mute = false;

    public static void play(String path) {
        parar();

        try {
            var url = MusicaManager.class.getResource(path);
            if (url == null) {
                System.err.println("No existe música: " + path);
                return;
            }

            AudioInputStream audio = AudioSystem.getAudioInputStream(url);
            musicClip = AudioSystem.getClip();
            musicClip.open(audio);

            gainControl = (FloatControl) musicClip.getControl(FloatControl.Type.MASTER_GAIN);
            setVolumen(volumen);

            musicClip.loop(Clip.LOOP_CONTINUOUSLY);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void parar() {
        if (musicClip != null && musicClip.isRunning()) {
            musicClip.stop();
            musicClip.close();
        }
    }

    public static void setVolumen(float v) {
        volumen = v;
        if (gainControl != null && !mute) {
            float dB = (float) (Math.log10(v) * 20);
            gainControl.setValue(dB);
        }
    }

    public static void toggleMute() {
        mute = !mute;
        setVolumen(mute ? 0.0001f : volumen);
    }
}
