package buscaminas.servidor;

import buscaminas.comunes.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Servidor{
    static List<ObjectOutputStream> clientes = new ArrayList<>();
    
    public static void main(String args[]) throws IOException {
        ServerSocket servidor = new ServerSocket(35558);
        BaseDatosBuscaminas bdb = new BaseDatosBuscaminas();
        
        while(true){
            Socket cliente = servidor.accept();
            
            new Thread(()-> manejarConexion(cliente, bdb)).start();
        }
    }
    
    public static void manejarConexion(Socket cliente, BaseDatosBuscaminas bdb){
        try {
            ObjectOutputStream salida = new ObjectOutputStream(cliente.getOutputStream());
            ObjectInputStream entrada = new ObjectInputStream(cliente.getInputStream());
            
            Mensaje inicial = (Mensaje) entrada.readObject();
            
            if(inicial.getTipo().equals("C_JUEGO")){
                if(clientes.size()<2){
                    clientes.add(salida);

                    salida.writeObject(new Mensaje("ACEPTADO",null));
                    int noJugador = clientes.size() - 1;
                    salida.writeObject(new Mensaje("JUGADOR",noJugador));

                    ManejoCliente manejador = new ManejoCliente(clientes, cliente, entrada, salida, noJugador, bdb);
                    manejador.start();
                }else{
                    salida.writeObject(new Mensaje("RECHAZADO",null));
                    cliente.close();
                }
            }else if(inicial.getTipo().equals("C_RANKING")){
                List<HistorialPartida> top = bdb.obtenerTop10Juegos();
                salida.writeObject(new Mensaje("RANKING",top));
                cliente.close();
            }else if(inicial.getTipo().equals("C_LOGIN")){
                try {
                    String[] datos = (String[]) inicial.getContenido();
                    System.out.println(datos);
                    System.out.println(datos[0]);
                    System.out.println(datos[1]);

                    JugadorStats j = bdb.obtenerJugador(datos[0]);
                    if(j!=null){
                        if(datos[1].equals(j.getContrasena())){
                            salida.writeObject(new Mensaje("INICIO",true));
                            //return;
                        }else{
                            salida.writeObject(new Mensaje("INICIO",false));
                            //return;
                        }
                    }else{
                        bdb.guardarJugadorNuevo(datos[0], datos[1]);
                        salida.writeObject(new Mensaje("CUENTA",true));
                        //return;
                    }
                }catch (Exception e) { 
                    //JOptionPane.showMessageDialog(null,"Campo nulo o error en formato de numero", "Error", JOptionPane.ERROR_MESSAGE);
                }
                cliente.close();
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}