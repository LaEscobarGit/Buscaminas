package buscaminas.comunes;

public class BaseDeDatos {
    
}
