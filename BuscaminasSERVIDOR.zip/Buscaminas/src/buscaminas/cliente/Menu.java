package buscaminas.cliente;

import buscaminas.comunes.GameBoardPanel;
import buscaminas.comunes.Mensaje;
import buscaminas.recursos.*;
import com.google.gson.Gson;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.HeadlessException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicButtonUI;


public class Menu extends javax.swing.JFrame {
    CardLayout cardLayout;
    CardLayout cardLayoutSmall;
    GameBoardPanel board;
    
    //socket
    Socket socket;
    ObjectInputStream entradaDatos;
    ObjectOutputStream salidaDatos;
    
    //tiempo
    private Thread hiloCrono;
    private boolean cronoCorre=false;
    int seg = 0;
    
    //usuario
    String nombre;
    int jugador;
    int vidas;
    boolean oListo;
    boolean jListo;
    String personaje = null;
    
    //oponente
    String personajeOP = null;
    int vidasOP;
    
    //Tablero
    String tableroStr = null;
    Tablero tablero;
    int filas;
    int columnas;
    int minas;
    
    public Menu() {
        initComponents();
        smallPane.setLayout(new CardLayout());
        GraphicsEnvironment en = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice dev = en.getDefaultScreenDevice();
        
        mainPane.add(menuPane, "menuPane");
        mainPane.add(optionPane, "optionPane");
        mainPane.add(perPane, "perPane");
        mainPane.add(modePane, "modePane");
        mainPane.add(gamePane, "gamePane");
        Component[] components = this.getContentPane().getComponents();
        for(Component component : components){
            if(component instanceof JButton){
                ((JButton) component).setUI(new BasicButtonUI());
                ((JButton) component).setFocusPainted(false);
            }
        }
        cardLayout = (CardLayout)(mainPane.getLayout());
        
        smallPane.add(botPane, "botPane");
        smallPane.add(logPane, "logPane");
        Component[] componentsSmall = menuPane.getComponents();
        for(Component component : componentsSmall){
            if(component instanceof JButton){
                ((JButton) component).setUI(new BasicButtonUI());
                ((JButton) component).setFocusPainted(false);
            }
        }
        cardLayoutSmall = (CardLayout)(smallPane.getLayout());
        cardLayoutSmall.show(smallPane, "logPane");
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Minesweeper");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPane = new javax.swing.JPanel();
        perPane = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jugarBot2 = new javax.swing.JButton();
        per1Bot = new javax.swing.JButton();
        per2Bot = new javax.swing.JButton();
        modePane = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        clasicBot = new javax.swing.JButton();
        batBot = new javax.swing.JButton();
        backBot = new javax.swing.JButton();
        optionPane = new javax.swing.JPanel();
        sigBot = new javax.swing.JButton();
        ezBot = new javax.swing.JButton();
        norBot = new javax.swing.JButton();
        hardBot = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        gamePane = new javax.swing.JPanel();
        boardPane = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        tiempoLabel = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        menuPane = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        smallPane = new javax.swing.JPanel();
        logPane = new javax.swing.JPanel();
        conectarBot = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        logField = new javax.swing.JTextField();
        botPane = new javax.swing.JPanel();
        jugarBot = new javax.swing.JButton();
        topBot = new javax.swing.JButton();
        salirBot = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        mainPane.setLayout(new java.awt.CardLayout());

        perPane.setBackground(new java.awt.Color(255, 204, 204));

        jPanel3.setBackground(new java.awt.Color(255, 153, 153));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 4));

        jLabel3.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Selecciona un personaje");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel3)
                .addContainerGap(27, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        jPanel1.setBackground(new java.awt.Color(255, 153, 153));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 4));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 258, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel2.setBackground(new java.awt.Color(255, 153, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 4));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 238, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel8.setBackground(new java.awt.Color(255, 153, 153));
        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 4));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 123, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 102, Short.MAX_VALUE)
        );

        jPanel9.setBackground(new java.awt.Color(255, 153, 153));
        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 4));

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 125, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jLabel4.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel4.setText("Jugador 1");

        jLabel5.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel5.setText("Jugador 2");

        jugarBot2.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jugarBot2.setText("Jugar");
        jugarBot2.setEnabled(false);
        jugarBot2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jugarBot2ActionPerformed(evt);
            }
        });

        per1Bot.setText("Roberto");
        per1Bot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                per1BotActionPerformed(evt);
            }
        });

        per2Bot.setText("AntiRoberto");
        per2Bot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                per2BotActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout perPaneLayout = new javax.swing.GroupLayout(perPane);
        perPane.setLayout(perPaneLayout);
        perPaneLayout.setHorizontalGroup(
            perPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(perPaneLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(perPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, perPaneLayout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)))
                .addGroup(perPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(perPaneLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33))
                    .addGroup(perPaneLayout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(per1Bot)
                        .addGap(64, 64, 64)
                        .addComponent(per2Bot)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
            .addGroup(perPaneLayout.createSequentialGroup()
                .addGap(112, 112, 112)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jugarBot2, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(198, 198, 198)
                .addComponent(jLabel5)
                .addGap(116, 116, 116))
        );
        perPaneLayout.setVerticalGroup(
            perPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(perPaneLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(perPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, perPaneLayout.createSequentialGroup()
                        .addGroup(perPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(perPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(per1Bot)
                            .addComponent(per2Bot))
                        .addGap(81, 81, 81))
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(perPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jugarBot2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(148, Short.MAX_VALUE))
        );

        mainPane.add(perPane, "card2");

        jLabel2.setFont(new java.awt.Font("Super Scribble", 0, 60)); // NOI18N
        jLabel2.setText("BUSCAMINAS");

        clasicBot.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        clasicBot.setText("Clásico");
        clasicBot.setEnabled(false);
        clasicBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clasicBotActionPerformed(evt);
            }
        });

        batBot.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        batBot.setText("Batalla");
        batBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                batBotActionPerformed(evt);
            }
        });

        backBot.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        backBot.setText("Regresar");
        backBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBotActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout modePaneLayout = new javax.swing.GroupLayout(modePane);
        modePane.setLayout(modePaneLayout);
        modePaneLayout.setHorizontalGroup(
            modePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modePaneLayout.createSequentialGroup()
                .addContainerGap(273, Short.MAX_VALUE)
                .addGroup(modePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(modePaneLayout.createSequentialGroup()
                        .addGap(120, 120, 120)
                        .addGroup(modePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(backBot, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(clasicBot, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(batBot, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel2))
                .addGap(268, 268, 268))
        );
        modePaneLayout.setVerticalGroup(
            modePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modePaneLayout.createSequentialGroup()
                .addContainerGap(170, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(clasicBot, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(batBot, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(backBot, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(170, 170, 170))
        );

        mainPane.add(modePane, "card3");

        sigBot.setText("Siguiente");
        sigBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sigBotActionPerformed(evt);
            }
        });

        ezBot.setText("EZ");
        ezBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ezBotActionPerformed(evt);
            }
        });

        norBot.setText("Normal");
        norBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                norBotActionPerformed(evt);
            }
        });

        hardBot.setText("BBC");
        hardBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hardBotActionPerformed(evt);
            }
        });

        jButton1.setText("Personalizado");

        javax.swing.GroupLayout optionPaneLayout = new javax.swing.GroupLayout(optionPane);
        optionPane.setLayout(optionPaneLayout);
        optionPaneLayout.setHorizontalGroup(
            optionPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, optionPaneLayout.createSequentialGroup()
                .addContainerGap(397, Short.MAX_VALUE)
                .addGroup(optionPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(sigBot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(hardBot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(norBot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ezBot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(400, 400, 400))
        );
        optionPaneLayout.setVerticalGroup(
            optionPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, optionPaneLayout.createSequentialGroup()
                .addGap(165, 165, 165)
                .addComponent(ezBot)
                .addGap(31, 31, 31)
                .addComponent(norBot)
                .addGap(28, 28, 28)
                .addComponent(hardBot)
                .addGap(31, 31, 31)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 155, Short.MAX_VALUE)
                .addComponent(sigBot)
                .addGap(59, 59, 59))
        );

        mainPane.add(optionPane, "card2");

        gamePane.setBackground(new java.awt.Color(255, 204, 204));

        boardPane.setBackground(new java.awt.Color(255, 153, 153));
        boardPane.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 4));

        javax.swing.GroupLayout boardPaneLayout = new javax.swing.GroupLayout(boardPane);
        boardPane.setLayout(boardPaneLayout);
        boardPaneLayout.setHorizontalGroup(
            boardPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 430, Short.MAX_VALUE)
        );
        boardPaneLayout.setVerticalGroup(
            boardPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 442, Short.MAX_VALUE)
        );

        jPanel12.setBackground(new java.awt.Color(255, 153, 153));
        jPanel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 4));

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 182, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 396, Short.MAX_VALUE)
        );

        tiempoLabel.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        tiempoLabel.setText("000");

        jLabel8.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel8.setText("Jugador 2");

        jLabel9.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel9.setText("Jugador 1");

        jPanel13.setBackground(new java.awt.Color(255, 153, 153));
        jPanel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 4));

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 174, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 397, Short.MAX_VALUE)
        );

        jLabel7.setText("1");

        jLabel10.setText("1");

        jLabel11.setText("1");

        javax.swing.GroupLayout gamePaneLayout = new javax.swing.GroupLayout(gamePane);
        gamePane.setLayout(gamePaneLayout);
        gamePaneLayout.setHorizontalGroup(
            gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, gamePaneLayout.createSequentialGroup()
                .addGroup(gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(gamePaneLayout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(tiempoLabel)
                        .addGap(206, 206, 206))
                    .addGroup(gamePaneLayout.createSequentialGroup()
                        .addContainerGap(25, Short.MAX_VALUE)
                        .addGroup(gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(gamePaneLayout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(boardPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, gamePaneLayout.createSequentialGroup()
                        .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, gamePaneLayout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(89, 89, 89))))
        );
        gamePaneLayout.setVerticalGroup(
            gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(gamePaneLayout.createSequentialGroup()
                .addContainerGap(41, Short.MAX_VALUE)
                .addGroup(gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(boardPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, gamePaneLayout.createSequentialGroup()
                        .addGroup(gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11))
                        .addGap(18, 18, 18)
                        .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(gamePaneLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tiempoLabel)
                            .addComponent(jLabel9)))
                    .addGroup(gamePaneLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel8)))
                .addGap(45, 45, 45))
        );

        mainPane.add(gamePane, "card2");

        jLabel1.setFont(new java.awt.Font("Super Scribble", 0, 60)); // NOI18N
        jLabel1.setText("BUSCAMINAS");

        smallPane.setLayout(new java.awt.CardLayout());

        conectarBot.setText("Conectar");
        conectarBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                conectarBotActionPerformed(evt);
            }
        });

        jLabel6.setText("Nombre:");

        javax.swing.GroupLayout logPaneLayout = new javax.swing.GroupLayout(logPane);
        logPane.setLayout(logPaneLayout);
        logPaneLayout.setHorizontalGroup(
            logPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logPaneLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(logPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(logField, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(logPaneLayout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(conectarBot)))
                .addContainerGap(65, Short.MAX_VALUE))
        );
        logPaneLayout.setVerticalGroup(
            logPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, logPaneLayout.createSequentialGroup()
                .addContainerGap(43, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(logField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(conectarBot)
                .addGap(77, 77, 77))
        );

        smallPane.add(logPane, "card2");

        jugarBot.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jugarBot.setText("Jugar");
        jugarBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jugarBotActionPerformed(evt);
            }
        });

        topBot.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        topBot.setText("Top 10");

        salirBot.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        salirBot.setText("Salir");

        javax.swing.GroupLayout botPaneLayout = new javax.swing.GroupLayout(botPane);
        botPane.setLayout(botPaneLayout);
        botPaneLayout.setHorizontalGroup(
            botPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(botPaneLayout.createSequentialGroup()
                .addGap(118, 118, 118)
                .addGroup(botPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(salirBot, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(topBot, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jugarBot, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(121, Short.MAX_VALUE))
        );
        botPaneLayout.setVerticalGroup(
            botPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(botPaneLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jugarBot, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(topBot, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(salirBot, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(37, Short.MAX_VALUE))
        );

        smallPane.add(botPane, "card3");

        javax.swing.GroupLayout menuPaneLayout = new javax.swing.GroupLayout(menuPane);
        menuPane.setLayout(menuPaneLayout);
        menuPaneLayout.setHorizontalGroup(
            menuPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuPaneLayout.createSequentialGroup()
                .addContainerGap(274, Short.MAX_VALUE)
                .addGroup(menuPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(smallPane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING))
                .addGap(267, 267, 267))
        );
        menuPaneLayout.setVerticalGroup(
            menuPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuPaneLayout.createSequentialGroup()
                .addGap(136, 136, 136)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(smallPane, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(142, Short.MAX_VALUE))
        );

        mainPane.add(menuPane, "card3");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBotActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_backBotActionPerformed

    private void clasicBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clasicBotActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_clasicBotActionPerformed

    private void batBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_batBotActionPerformed
        try {
            socket = new Socket("localhost",35558);
            salidaDatos = new ObjectOutputStream(socket.getOutputStream());
            salidaDatos.flush();
            entradaDatos = new ObjectInputStream(socket.getInputStream());
            
            //PRUEBAS
            System.out.println("salida y entrada ready");
            
            try{
                Mensaje msj = (Mensaje) entradaDatos.readObject();
                if("RECHAZADO".equals(msj.getTipo())){
                    JOptionPane.showMessageDialog(this, "Lleno, intenta mas tarde");
                    salidaDatos.close();
                    entradaDatos.close();
                    socket.close();
                    return;
                }
            }catch(HeadlessException | IOException | ClassNotFoundException e){
                //
            }
            
            escucharMensaje();
            enviarMensaje("NOMBRE",nombre);
            enviarMensaje("CONEXION",null);
            
            if(oListo==false){
                System.out.println("Buscando jugador");
            }
        } catch (IOException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_batBotActionPerformed

    private void jugarBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jugarBotActionPerformed
        cardLayout.show(mainPane, "modePane");
    }//GEN-LAST:event_jugarBotActionPerformed

    private void jugarBot2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jugarBot2ActionPerformed
        enviarMensaje("SELECCION", true);
        if(jListo==false){
            System.out.println("Eligiendo personaje");
        }
    }//GEN-LAST:event_jugarBot2ActionPerformed

    private void sigBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sigBotActionPerformed
        if(jugador==1){
            enviarMensaje("TABLERO", tableroStr);
            enviarMensaje("OPCIONES", true);
        }
        cardLayout.show(mainPane, "perPane");
    }//GEN-LAST:event_sigBotActionPerformed

    private void conectarBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_conectarBotActionPerformed
        nombre = logField.getText().trim();
        if(nombre.isEmpty()){
            JOptionPane.showMessageDialog(this, "Ingresa un nombre");
            return;
        }
        cardLayoutSmall.show(smallPane, "botPane");
    }//GEN-LAST:event_conectarBotActionPerformed

    private void ezBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ezBotActionPerformed
        tableroStr = "Principiante";
    }//GEN-LAST:event_ezBotActionPerformed

    private void norBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_norBotActionPerformed
        tableroStr = "Intermedio";
    }//GEN-LAST:event_norBotActionPerformed

    private void hardBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hardBotActionPerformed
        tableroStr = "Avanzado";
    }//GEN-LAST:event_hardBotActionPerformed

    private void per1BotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_per1BotActionPerformed
        personaje = "Roberto";
        enviarMensaje("PERSONAJE", personaje);
        if(jugador==1){
            jugarBot2.setEnabled(true);
        }
    }//GEN-LAST:event_per1BotActionPerformed

    private void per2BotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_per2BotActionPerformed
        personaje = "AntiRoberto";
        enviarMensaje("PERSONAJE", personaje);
        if(jugador==1){
            jugarBot2.setEnabled(true);
        }
    }//GEN-LAST:event_per2BotActionPerformed

    //tiempo
    public void setCrono(){
        cronoCorre=true;
        seg=0;
        tiempoLabel.setText("000");
        hiloCrono = new Thread(() -> {
            try {
                while(cronoCorre){
                    Thread.sleep(1000);
                    seg++;
                    String tiempo = String.format("%02d",seg);
                    tiempoLabel.setText(tiempo);
                }
            }catch(InterruptedException ex){
                ex.printStackTrace();
            }
        });
        hiloCrono.start();
    }
    public int pararCrono(){
        hiloCrono.interrupt();
        cronoCorre=false;
        return seg;
    }
    
    public void terminarJuego(boolean vivir){
        if(vivir){
            enviarMensaje("VIVIR",true);
            //mostrar pantalla ganadora
        }else{
            enviarMensaje("VIVIR",false);
            //mostrar pantalla perdedora
        }
    }
    
    public void perderVida(int vidas){
        this.vidas = vidas;
        enviarMensaje("VIDAS",vidas);
    }
    
    public void escucharMensaje(){
        new Thread(()->{
            try{
                while(true){
                    Object obj = entradaDatos.readObject();
                    Mensaje msj = (Mensaje) obj;
                    System.out.println("Servidor dice:" + msj);
                    decodificar(msj);
                }
            }catch(IOException | ClassNotFoundException e){
                //
            }
        }).start();
    }
    
    public void decodificar(Mensaje msj){
        switch(msj.getTipo()){
            case "CONEXION":if((Integer) msj.getContenido()==1){
                                oListo = false;
                            }else if((Integer) msj.getContenido()==2){
                                oListo = true;
                                if(jugador==1){
                                    cardLayout.show(mainPane, "optionPane");
                                }else if(jugador==2){
                                    System.out.println("Jugador 1 esta eligiendo");
                                }
                            }   
            break;
            case "JUGADOR": jugador = ((Integer) msj.getContenido())+1;
            break;
            case "TABLERO": tableroStr = String.valueOf(msj.getContenido());
                            try(InputStream input = getClass().getResourceAsStream("/buscaminas/recursos/tableros.json")){
                                InputStreamReader reader = new InputStreamReader(input);
                                Gson gson = new Gson();
                                TablerosConfig config = gson.fromJson(reader, TablerosConfig.class);
                                tablero = config.buscarPorNombre(tableroStr);
                               
                                filas = tablero.getFilas();
                                columnas = tablero.getColumnas();
                                minas = tablero.getMinas();
                            }catch(Exception e){
                                //
                            }      
            break;
            case "OPCIONES":if((Boolean) msj.getContenido()){
                                cardLayout.show(mainPane, "perPane");
                            }
            break;
            case "OPONENTE": personajeOP = String.valueOf(msj.getContenido());
            break;
            case "SELECCION":if(!(Boolean) msj.getContenido()){
                                jListo = false;
                            }else if((Boolean) msj.getContenido()){
                                jListo = true;
                                board = new GameBoardPanel(this, filas, columnas, minas);
                                cardLayout.show(mainPane, "gamePane");
                                boardPane.setLayout(new BorderLayout());
                                boardPane.add(board, BorderLayout.CENTER);
                                boardPane.revalidate();
                                boardPane.repaint();
                            }   
            break;
            case "VIDAS": vidasOP = (Integer) msj.getContenido();
            break;
            case "DESCONECTADO": 
            break;
            case "EXIT": 
            break;
        }
    }
    
    public void enviarMensaje(String tipo, Object contenido){
        try{
            Mensaje msj = new Mensaje(tipo, contenido);
            salidaDatos.writeObject(msj);
            salidaDatos.flush();
            System.out.println(msj);
        }catch(IOException e){
            
        }
    }
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backBot;
    private javax.swing.JButton batBot;
    private javax.swing.JPanel boardPane;
    private javax.swing.JPanel botPane;
    private javax.swing.JButton clasicBot;
    private javax.swing.JButton conectarBot;
    private javax.swing.JButton ezBot;
    private javax.swing.JPanel gamePane;
    private javax.swing.JButton hardBot;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JButton jugarBot;
    private javax.swing.JButton jugarBot2;
    private javax.swing.JTextField logField;
    private javax.swing.JPanel logPane;
    private javax.swing.JPanel mainPane;
    private javax.swing.JPanel menuPane;
    private javax.swing.JPanel modePane;
    private javax.swing.JButton norBot;
    private javax.swing.JPanel optionPane;
    private javax.swing.JButton per1Bot;
    private javax.swing.JButton per2Bot;
    private javax.swing.JPanel perPane;
    private javax.swing.JButton salirBot;
    private javax.swing.JButton sigBot;
    private javax.swing.JPanel smallPane;
    private javax.swing.JLabel tiempoLabel;
    private javax.swing.JButton topBot;
    // End of variables declaration//GEN-END:variables
}
