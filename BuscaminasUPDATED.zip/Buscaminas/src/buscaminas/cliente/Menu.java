package buscaminas.cliente;

import buscaminas.recursos.*;
import buscaminas.comunes.*;
import buscaminas.recursos.audio.*;
import com.formdev.flatlaf.FlatLightLaf;
import com.google.gson.Gson;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.plaf.basic.BasicButtonUI;


public class Menu extends javax.swing.JFrame {
    CardLayout cardLayout;
    CardLayout cardLayoutSmall;
    GameBoardPanel board;
    HistorialPartida partida;
    
    //socket
    Socket socket;
    ObjectInputStream entradaDatos;
    ObjectOutputStream salidaDatos;
    
    //tiempo
    private Thread hiloCrono;
    private boolean cronoCorre=false;
    int seg = 0;
    
    //usuario
    String nombre;
    String cont;
    int jugador;
    boolean oListo;
    boolean jListo;
    String personaje = null;
    int vidas;
    int puntos;
    boolean terminar;
    boolean ganador;
    
    //oponente
    String nombreOP;
    String personajeOP = null;
    int vidasOP;
    int puntosOP;
    boolean terminarOP;
    
    //Tablero
    String tableroStr = null;
    Tablero tablero;
    int filas;
    int columnas;
    int minas;
    
    //Waiting
    LoadingFrame waiting;
    
    //GUI
    private String tarjetaActual = "Roberto";
    
    public Menu() {
        initComponents();
        setLocationRelativeTo(null);
        
        // Cursor customizado
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Image cursorImage = toolkit.getImage(getClass().getResource("/buscaminas/recursos/imagenes/pointer.png"));
        Cursor customCursor = toolkit.createCustomCursor(cursorImage, new Point(0, 0), "customCursor");
        setCursor(customCursor);
        
        // Chara Select Stuff //
        charaSelectPanel.add(chara1Panel, "Roberto");
        charaSelectPanel.add(chara2Panel, "AntiRoberto");
        
        smallPane.setLayout(new CardLayout());
        GraphicsEnvironment en = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice dev = en.getDefaultScreenDevice();
        
        mainPane.add(menuPane, "menuPane");
        mainPane.add(optionPane, "optionPane");
        mainPane.add(perPane, "perPane");
        mainPane.add(modePane, "modePane");
        mainPane.add(gamePane, "gamePane");
        mainPane.add(rankPane, "rankPane");
        mainPane.add(waitPane, "waitPane");
        mainPane.add(loserPane, "loserPane");
        mainPane.add(winnerPane, "winnerPane");
        Component[] components = this.getContentPane().getComponents();
        for(Component component : components){
            if(component instanceof JButton){
                ((JButton) component).setUI(new BasicButtonUI());
                ((JButton) component).setFocusPainted(false);
            }
        }
        cardLayout = (CardLayout)(mainPane.getLayout());
        
        smallPane.add(botPane, "botPane");
        smallPane.add(logPane, "logPane");
        Component[] componentsSmall = menuPane.getComponents();
        for(Component component : componentsSmall){
            if(component instanceof JButton){
                ((JButton) component).setUI(new BasicButtonUI());
                ((JButton) component).setFocusPainted(false);
            }
        }
        cardLayoutSmall = (CardLayout)(smallPane.getLayout());
        cardLayoutSmall.show(smallPane, "logPane");
        
        AudioManager.agregarSonidoBotones(this, "/buscaminas/recursos/audio/click1.wav","/buscaminas/recursos/audio/hover.wav");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Minesweeper");
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPane = new javax.swing.JPanel();
        menuPane = new buscaminas.recursos.Fondo("/buscaminas/recursos/imagenes/logoscreen.png");
        smallPane = new javax.swing.JPanel();
        logPane = new javax.swing.JPanel();
        conectarBot = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        logField = new javax.swing.JTextField();
        contField = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        botPane = new javax.swing.JPanel();
        jugarBot = new javax.swing.JButton();
        topBot = new javax.swing.JButton();
        salirBot = new javax.swing.JButton();
        rankPane = new buscaminas.recursos.Fondo("/buscaminas/recursos/imagenes/rankscreen.png");
        jButton1 = new javax.swing.JButton();
        jPanel15 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        top1 = new javax.swing.JLabel();
        top2 = new javax.swing.JLabel();
        top3 = new javax.swing.JLabel();
        top4 = new javax.swing.JLabel();
        top5 = new javax.swing.JLabel();
        top6 = new javax.swing.JLabel();
        top7 = new javax.swing.JLabel();
        top8 = new javax.swing.JLabel();
        top9 = new javax.swing.JLabel();
        top10 = new javax.swing.JLabel();
        points1 = new javax.swing.JLabel();
        points2 = new javax.swing.JLabel();
        points3 = new javax.swing.JLabel();
        points4 = new javax.swing.JLabel();
        points5 = new javax.swing.JLabel();
        points6 = new javax.swing.JLabel();
        points7 = new javax.swing.JLabel();
        points8 = new javax.swing.JLabel();
        points9 = new javax.swing.JLabel();
        points10 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        optionPane = new buscaminas.recursos.Fondo("/buscaminas/recursos/imagenes/menuscreen.png");
        jPanel5 = new javax.swing.JPanel();
        sigBot = new javax.swing.JButton();
        norBot = new javax.swing.JButton();
        ezBot = new javax.swing.JButton();
        hardBot = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        modePane = new buscaminas.recursos.Fondo("/buscaminas/recursos/imagenes/menuscreen.png");
        jLabel12 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        clasicBot = new javax.swing.JButton();
        backBot = new javax.swing.JButton();
        batBot = new javax.swing.JButton();
        gamePane = new buscaminas.recursos.Fondo("/buscaminas/recursos/imagenes/gamescreen.png");
        boardPane = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        tiempoLabel = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        p1h3 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        p1h2 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        p1h1 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        p2h1 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        p2h2 = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        p2h3 = new javax.swing.JLabel();
        jug1Label = new javax.swing.JLabel();
        jug2Label = new javax.swing.JLabel();
        perPane = new buscaminas.recursos.Fondo("/buscaminas/recursos/imagenes/charaSelScreen.png");
        jLabel3 = new javax.swing.JLabel();
        charaSelectPanel = new javax.swing.JPanel();
        chara1Panel = new javax.swing.JPanel();
        chara1 = new javax.swing.JLabel();
        chara2Panel = new javax.swing.JPanel();
        chara2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        flechaDer = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        flechaIzq = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jugarBot2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel15 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        waitPane = new buscaminas.recursos.Fondo("/buscaminas/recursos/imagenes/waitscreen.png");
        loserPane = new buscaminas.recursos.Fondo("/buscaminas/recursos/imagenes/loserScreen.png");
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        winnerPane = new buscaminas.recursos.Fondo("/buscaminas/recursos/imagenes/winnerScreen.png");
        jButton3 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        offMenu = new javax.swing.JMenu();
        confMenu = new javax.swing.JMenu();
        infoMenu = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Lovesweeper");
        setMinimumSize(new java.awt.Dimension(1024, 576));
        setResizable(false);
        setSize(new java.awt.Dimension(1024, 576));

        mainPane.setLayout(new java.awt.CardLayout());

        menuPane.setMaximumSize(new java.awt.Dimension(1024, 576));
        menuPane.setMinimumSize(new java.awt.Dimension(1004, 576));
        menuPane.setPreferredSize(new java.awt.Dimension(1024, 576));

        smallPane.setOpaque(false);
        smallPane.setLayout(new java.awt.CardLayout());

        logPane.setOpaque(false);

        conectarBot.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        conectarBot.setText("♥ Enter ♥");
        conectarBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                conectarBotActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("User:");

        contField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contFieldActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        jLabel18.setText("Pass:");

        javax.swing.GroupLayout logPaneLayout = new javax.swing.GroupLayout(logPane);
        logPane.setLayout(logPaneLayout);
        logPaneLayout.setHorizontalGroup(
            logPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, logPaneLayout.createSequentialGroup()
                .addContainerGap(79, Short.MAX_VALUE)
                .addGroup(logPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(logField, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(conectarBot, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(contField, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18))
                .addGap(78, 78, 78))
        );
        logPaneLayout.setVerticalGroup(
            logPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logPaneLayout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(logField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(contField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(conectarBot, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(52, Short.MAX_VALUE))
        );

        smallPane.add(logPane, "card2");

        botPane.setOpaque(false);

        jugarBot.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        jugarBot.setText("Play");
        jugarBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jugarBotActionPerformed(evt);
            }
        });

        topBot.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        topBot.setText("Ranking");
        topBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                topBotActionPerformed(evt);
            }
        });

        salirBot.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        salirBot.setText("Exit");
        salirBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salirBotActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout botPaneLayout = new javax.swing.GroupLayout(botPane);
        botPane.setLayout(botPaneLayout);
        botPaneLayout.setHorizontalGroup(
            botPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, botPaneLayout.createSequentialGroup()
                .addGap(147, 147, 147)
                .addGroup(botPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jugarBot, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(topBot, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(salirBot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(147, 147, 147))
        );
        botPaneLayout.setVerticalGroup(
            botPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(botPaneLayout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addComponent(jugarBot, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(topBot, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(salirBot, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
                .addGap(85, 85, 85))
        );

        smallPane.add(botPane, "card3");

        javax.swing.GroupLayout menuPaneLayout = new javax.swing.GroupLayout(menuPane);
        menuPane.setLayout(menuPaneLayout);
        menuPaneLayout.setHorizontalGroup(
            menuPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuPaneLayout.createSequentialGroup()
                .addGap(305, 305, 305)
                .addComponent(smallPane, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(305, Short.MAX_VALUE))
        );
        menuPaneLayout.setVerticalGroup(
            menuPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuPaneLayout.createSequentialGroup()
                .addContainerGap(227, Short.MAX_VALUE)
                .addComponent(smallPane, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );

        mainPane.add(menuPane, "card3");

        rankPane.setMaximumSize(new java.awt.Dimension(1024, 576));
        rankPane.setMinimumSize(new java.awt.Dimension(1024, 576));

        jButton1.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        jButton1.setText("BACK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jPanel15.setMaximumSize(new java.awt.Dimension(584, 308));
        jPanel15.setMinimumSize(new java.awt.Dimension(584, 308));
        jPanel15.setOpaque(false);
        jPanel15.setPreferredSize(new java.awt.Dimension(584, 308));

        jLabel4.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel4.setText("1ST");

        jLabel19.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel19.setText("2ND");

        jLabel20.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel20.setText("3RD");

        jLabel21.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel21.setText("4TH");

        jLabel22.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel22.setText("5TH");

        jLabel23.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel23.setText("6TH");

        jLabel24.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel24.setText("7TH");

        jLabel25.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel25.setText("8TH");

        jLabel26.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel26.setText("9TH");

        jLabel27.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel27.setText("10TH");

        top1.setFont(new java.awt.Font("PixelMplus10", 1, 14)); // NOI18N
        top1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        top1.setText("USER");

        top2.setFont(new java.awt.Font("PixelMplus10", 1, 14)); // NOI18N
        top2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        top2.setText("USER");

        top3.setFont(new java.awt.Font("PixelMplus10", 1, 14)); // NOI18N
        top3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        top3.setText("USER");

        top4.setFont(new java.awt.Font("PixelMplus10", 1, 14)); // NOI18N
        top4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        top4.setText("USER");

        top5.setFont(new java.awt.Font("PixelMplus10", 1, 14)); // NOI18N
        top5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        top5.setText("USER");

        top6.setFont(new java.awt.Font("PixelMplus10", 1, 14)); // NOI18N
        top6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        top6.setText("USER");

        top7.setFont(new java.awt.Font("PixelMplus10", 1, 14)); // NOI18N
        top7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        top7.setText("USER");

        top8.setFont(new java.awt.Font("PixelMplus10", 1, 14)); // NOI18N
        top8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        top8.setText("USER");

        top9.setFont(new java.awt.Font("PixelMplus10", 1, 14)); // NOI18N
        top9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        top9.setText("USER");

        top10.setFont(new java.awt.Font("PixelMplus10", 1, 14)); // NOI18N
        top10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        top10.setText("USER");

        points1.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        points1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        points1.setText("POINTS");

        points2.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        points2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        points2.setText("POINTS");

        points3.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        points3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        points3.setText("POINTS");

        points4.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        points4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        points4.setText("POINTS");

        points5.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        points5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        points5.setText("POINTS");

        points6.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        points6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        points6.setText("POINTS");

        points7.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        points7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        points7.setText("POINTS");

        points8.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        points8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        points8.setText("POINTS");

        points9.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        points9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        points9.setText("POINTS");

        points10.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        points10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        points10.setText("POINTS");

        jLabel48.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel48.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel48.setText("♥♥♥");

        jLabel49.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel49.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel49.setText("♥♥♥");
        jLabel49.setToolTipText("");

        jLabel50.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel50.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel50.setText("♥♥♥");
        jLabel50.setToolTipText("");

        jLabel51.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel51.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel51.setText("♥♥♥");
        jLabel51.setToolTipText("");

        jLabel52.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel52.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel52.setText("♥♥♥");
        jLabel52.setToolTipText("");

        jLabel53.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel53.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel53.setText("♥♥♥");
        jLabel53.setToolTipText("");

        jLabel54.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel54.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel54.setText("♥♥♥");
        jLabel54.setToolTipText("");

        jLabel55.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel55.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel55.setText("♥♥♥");
        jLabel55.setToolTipText("");

        jLabel56.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel56.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel56.setText("♥♥♥");
        jLabel56.setToolTipText("");

        jLabel57.setFont(new java.awt.Font("PixelMplus10", 0, 14)); // NOI18N
        jLabel57.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel57.setText("♥♥♥");
        jLabel57.setToolTipText("");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(top2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(top3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(top4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(top5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(top6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(top7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(top8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(top9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(top10, javax.swing.GroupLayout.DEFAULT_SIZE, 163, Short.MAX_VALUE)
                    .addComponent(top1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(points9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 163, Short.MAX_VALUE)
                    .addComponent(points8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(points7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(points6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(points5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(points4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(points3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(points2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(points1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(points10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel49, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel50, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel51, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel52, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel53, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel54, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel55, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel56, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel57, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(64, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(top1)
                    .addComponent(points1)
                    .addComponent(jLabel48))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(top2)
                    .addComponent(points2)
                    .addComponent(jLabel49))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(top3)
                    .addComponent(points3)
                    .addComponent(jLabel50))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(top4)
                    .addComponent(points4)
                    .addComponent(jLabel51))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(top5)
                    .addComponent(points5)
                    .addComponent(jLabel52))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(top6)
                    .addComponent(points6)
                    .addComponent(jLabel53))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(top7)
                    .addComponent(points7)
                    .addComponent(jLabel54))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(top8)
                    .addComponent(points8)
                    .addComponent(jLabel55))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(top9)
                    .addComponent(points9)
                    .addComponent(jLabel56))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(top10)
                    .addComponent(points10)
                    .addComponent(jLabel57))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jLabel9.setFont(new java.awt.Font("DinkieBitmap 7px Demo", 0, 48)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("TOP 10");

        javax.swing.GroupLayout rankPaneLayout = new javax.swing.GroupLayout(rankPane);
        rankPane.setLayout(rankPaneLayout);
        rankPaneLayout.setHorizontalGroup(
            rankPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rankPaneLayout.createSequentialGroup()
                .addGap(220, 220, 220)
                .addGroup(rankPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 584, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(220, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, rankPaneLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(451, 451, 451))
        );
        rankPaneLayout.setVerticalGroup(
            rankPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, rankPaneLayout.createSequentialGroup()
                .addContainerGap(62, Short.MAX_VALUE)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50))
        );

        mainPane.add(rankPane, "card7");

        optionPane.setMaximumSize(new java.awt.Dimension(1024, 576));
        optionPane.setMinimumSize(new java.awt.Dimension(1024, 576));
        optionPane.setPreferredSize(new java.awt.Dimension(1024, 576));

        jPanel5.setOpaque(false);

        sigBot.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        sigBot.setText("NEXT");
        sigBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sigBotActionPerformed(evt);
            }
        });

        norBot.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        norBot.setText("Normal");
        norBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                norBotActionPerformed(evt);
            }
        });

        ezBot.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        ezBot.setText("EZ");
        ezBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ezBotActionPerformed(evt);
            }
        });

        hardBot.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        hardBot.setText("♥ VERY HARD ♥");
        hardBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hardBotActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(sigBot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(hardBot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(norBot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ezBot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(94, 94, 94))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(ezBot, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(norBot, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(hardBot, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(sigBot, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(85, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("DinkieBitmap 7px Demo", 1, 48)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("DIFFICULTY");

        javax.swing.GroupLayout optionPaneLayout = new javax.swing.GroupLayout(optionPane);
        optionPane.setLayout(optionPaneLayout);
        optionPaneLayout.setHorizontalGroup(
            optionPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, optionPaneLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(optionPaneLayout.createSequentialGroup()
                .addGap(331, 331, 331)
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(330, 330, 330))
        );
        optionPaneLayout.setVerticalGroup(
            optionPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, optionPaneLayout.createSequentialGroup()
                .addContainerGap(128, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );

        mainPane.add(optionPane, "card2");

        modePane.setMaximumSize(new java.awt.Dimension(1024, 576));
        modePane.setMinimumSize(new java.awt.Dimension(1024, 576));
        modePane.setPreferredSize(new java.awt.Dimension(1024, 576));

        jLabel12.setFont(new java.awt.Font("DinkieBitmap 7px Demo", 1, 48)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("GAME MODE");

        jPanel4.setOpaque(false);

        clasicBot.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        clasicBot.setText("Classic");
        clasicBot.setEnabled(false);
        clasicBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clasicBotActionPerformed(evt);
            }
        });

        backBot.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        backBot.setText("Back");
        backBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBotActionPerformed(evt);
            }
        });

        batBot.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        batBot.setText("Battle");
        batBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                batBotActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(batBot, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(backBot, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(clasicBot, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE))
                .addGap(67, 67, 67))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(clasicBot, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(batBot, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(backBot, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(85, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout modePaneLayout = new javax.swing.GroupLayout(modePane);
        modePane.setLayout(modePaneLayout);
        modePaneLayout.setHorizontalGroup(
            modePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modePaneLayout.createSequentialGroup()
                .addGap(385, 385, 385)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(384, 384, 384))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modePaneLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 1012, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        modePaneLayout.setVerticalGroup(
            modePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modePaneLayout.createSequentialGroup()
                .addContainerGap(185, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );

        mainPane.add(modePane, "card3");

        gamePane.setMaximumSize(new java.awt.Dimension(1024, 576));
        gamePane.setMinimumSize(new java.awt.Dimension(1024, 576));

        boardPane.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        boardPane.setOpaque(false);

        javax.swing.GroupLayout boardPaneLayout = new javax.swing.GroupLayout(boardPane);
        boardPane.setLayout(boardPaneLayout);
        boardPaneLayout.setHorizontalGroup(
            boardPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 422, Short.MAX_VALUE)
        );
        boardPaneLayout.setVerticalGroup(
            boardPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 422, Short.MAX_VALUE)
        );

        jPanel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel12.setOpaque(false);
        jPanel12.setPreferredSize(new java.awt.Dimension(192, 272));

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 190, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 270, Short.MAX_VALUE)
        );

        tiempoLabel.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        tiempoLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tiempoLabel.setText("000");

        jPanel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel13.setOpaque(false);
        jPanel13.setPreferredSize(new java.awt.Dimension(192, 272));

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 190, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 270, Short.MAX_VALUE)
        );

        jPanel1.setOpaque(false);

        p1h3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p1h3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/lives2.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(p1h3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(p1h3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel7.setOpaque(false);

        p1h2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p1h2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/lives2.png"))); // NOI18N

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(p1h2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(p1h2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel9.setOpaque(false);

        p1h1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p1h1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/lives2.png"))); // NOI18N

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(p1h1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(p1h1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel10.setOpaque(false);

        p2h1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p2h1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/lives2.png"))); // NOI18N

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(p2h1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(p2h1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel11.setOpaque(false);

        p2h2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p2h2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/lives2.png"))); // NOI18N

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(p2h2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(p2h2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel14.setOpaque(false);

        p2h3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p2h3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/lives2.png"))); // NOI18N

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(p2h3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(p2h3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jug1Label.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        jug1Label.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jug1Label.setText("PLAYER 1");

        jug2Label.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        jug2Label.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jug2Label.setText("PLAYER 2");

        javax.swing.GroupLayout gamePaneLayout = new javax.swing.GroupLayout(gamePane);
        gamePane.setLayout(gamePaneLayout);
        gamePaneLayout.setHorizontalGroup(
            gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(gamePaneLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jug1Label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(gamePaneLayout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(48, 48, 48)
                .addGroup(gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tiempoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 424, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(gamePaneLayout.createSequentialGroup()
                        .addComponent(boardPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48)
                        .addGroup(gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jug2Label, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(gamePaneLayout.createSequentialGroup()
                                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(60, Short.MAX_VALUE))
        );
        gamePaneLayout.setVerticalGroup(
            gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(gamePaneLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jug2Label)
                    .addComponent(jug1Label))
                .addGap(18, 18, 18)
                .addGroup(gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(gamePaneLayout.createSequentialGroup()
                        .addGroup(gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(36, 36, 36)
                        .addGroup(gamePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(boardPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addComponent(tiempoLabel)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        mainPane.add(gamePane, "card2");

        perPane.setMaximumSize(new java.awt.Dimension(1024, 576));
        perPane.setMinimumSize(new java.awt.Dimension(1024, 576));
        perPane.setPreferredSize(new java.awt.Dimension(1024, 576));

        jLabel3.setFont(new java.awt.Font("DinkieBitmap 7px Demo", 1, 24)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("CHOOSE YOUR FIGHTER");

        charaSelectPanel.setOpaque(false);
        charaSelectPanel.setLayout(new java.awt.CardLayout());

        chara1Panel.setOpaque(false);

        chara1.setFont(new java.awt.Font("PixelMplus10", 0, 10)); // NOI18N
        chara1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        chara1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/robertuwu.png"))); // NOI18N

        javax.swing.GroupLayout chara1PanelLayout = new javax.swing.GroupLayout(chara1Panel);
        chara1Panel.setLayout(chara1PanelLayout);
        chara1PanelLayout.setHorizontalGroup(
            chara1PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, chara1PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(chara1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        chara1PanelLayout.setVerticalGroup(
            chara1PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(chara1PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(chara1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        charaSelectPanel.add(chara1Panel, "card2");

        chara2Panel.setMaximumSize(new java.awt.Dimension(276, 392));
        chara2Panel.setMinimumSize(new java.awt.Dimension(276, 392));
        chara2Panel.setOpaque(false);
        chara2Panel.setPreferredSize(new java.awt.Dimension(276, 392));

        chara2.setFont(new java.awt.Font("PixelMplus10", 0, 10)); // NOI18N
        chara2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        chara2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/antiroberto.png"))); // NOI18N

        javax.swing.GroupLayout chara2PanelLayout = new javax.swing.GroupLayout(chara2Panel);
        chara2Panel.setLayout(chara2PanelLayout);
        chara2PanelLayout.setHorizontalGroup(
            chara2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(chara2PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(chara2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        chara2PanelLayout.setVerticalGroup(
            chara2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(chara2PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(chara2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        charaSelectPanel.add(chara2Panel, "card3");

        jPanel2.setOpaque(false);

        flechaDer.setFont(new java.awt.Font("PixelMplus10", 0, 10)); // NOI18N
        flechaDer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/arrowRight.png"))); // NOI18N
        flechaDer.setBorderPainted(false);
        flechaDer.setContentAreaFilled(false);
        flechaDer.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/arrowRightPressed.png"))); // NOI18N
        flechaDer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                flechaDerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(flechaDer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(flechaDer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel3.setOpaque(false);

        flechaIzq.setFont(new java.awt.Font("PixelMplus10", 0, 10)); // NOI18N
        flechaIzq.setIcon(new javax.swing.ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/arrowLeft.png"))); // NOI18N
        flechaIzq.setBorderPainted(false);
        flechaIzq.setContentAreaFilled(false);
        flechaIzq.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/arrowLeftPressed.png"))); // NOI18N
        flechaIzq.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                flechaIzqActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(flechaIzq, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(flechaIzq, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel6.setOpaque(false);

        jugarBot2.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        jugarBot2.setText("♥ SELECT ♥");
        jugarBot2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jugarBot2ActionPerformed(evt);
            }
        });

        jScrollPane1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Backstory ♥", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("PixelMplus10", 0, 10))); // NOI18N

        jTextArea1.setColumns(20);
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setText("ロベルトはプログラマーで、マインスイーパが大好きで、愛を見つけるためにここにいます。");
        jTextArea1.setWrapStyleWord(true);
        jScrollPane1.setViewportView(jTextArea1);

        jLabel15.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText("ROBERTO");

        jPanel8.setOpaque(false);

        jLabel13.setFont(new java.awt.Font("PixelMplus10", 0, 10)); // NOI18N
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/normalMug.png"))); // NOI18N

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(47, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jugarBot2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(49, 49, 49))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel15)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jugarBot2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout perPaneLayout = new javax.swing.GroupLayout(perPane);
        perPane.setLayout(perPaneLayout);
        perPaneLayout.setHorizontalGroup(
            perPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, perPaneLayout.createSequentialGroup()
                .addGap(92, 92, 92)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(perPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(perPaneLayout.createSequentialGroup()
                        .addComponent(charaSelectPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(87, 87, 87))
        );
        perPaneLayout.setVerticalGroup(
            perPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(perPaneLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(perPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(perPaneLayout.createSequentialGroup()
                        .addGap(112, 112, 112)
                        .addGroup(perPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(charaSelectPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(74, Short.MAX_VALUE))
        );

        mainPane.add(perPane, "card2");

        waitPane.setMaximumSize(new java.awt.Dimension(1024, 576));
        waitPane.setMinimumSize(new java.awt.Dimension(1024, 576));
        waitPane.setPreferredSize(new java.awt.Dimension(1024, 576));

        javax.swing.GroupLayout waitPaneLayout = new javax.swing.GroupLayout(waitPane);
        waitPane.setLayout(waitPaneLayout);
        waitPaneLayout.setHorizontalGroup(
            waitPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1024, Short.MAX_VALUE)
        );
        waitPaneLayout.setVerticalGroup(
            waitPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 576, Short.MAX_VALUE)
        );

        mainPane.add(waitPane, "card8");

        loserPane.setMaximumSize(new java.awt.Dimension(1024, 576));
        loserPane.setMinimumSize(new java.awt.Dimension(1024, 576));
        loserPane.setPreferredSize(new java.awt.Dimension(1024, 576));

        jLabel1.setFont(new java.awt.Font("PixelMplus10", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("000");

        jButton2.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        jButton2.setText("BACK");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout loserPaneLayout = new javax.swing.GroupLayout(loserPane);
        loserPane.setLayout(loserPaneLayout);
        loserPaneLayout.setHorizontalGroup(
            loserPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loserPaneLayout.createSequentialGroup()
                .addGroup(loserPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(loserPaneLayout.createSequentialGroup()
                        .addGap(789, 789, 789)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(loserPaneLayout.createSequentialGroup()
                        .addGap(273, 273, 273)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        loserPaneLayout.setVerticalGroup(
            loserPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loserPaneLayout.createSequentialGroup()
                .addGap(308, 308, 308)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 156, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addGap(57, 57, 57))
        );

        mainPane.add(loserPane, "card9");

        winnerPane.setMaximumSize(new java.awt.Dimension(1024, 576));
        winnerPane.setMinimumSize(new java.awt.Dimension(1024, 576));

        jButton3.setFont(new java.awt.Font("PixelMplus10", 0, 18)); // NOI18N
        jButton3.setText("BACK");
        jButton3.setMaximumSize(new java.awt.Dimension(75, 28));
        jButton3.setMinimumSize(new java.awt.Dimension(75, 28));
        jButton3.setPreferredSize(new java.awt.Dimension(75, 28));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("PixelMplus10", 0, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("000");

        javax.swing.GroupLayout winnerPaneLayout = new javax.swing.GroupLayout(winnerPane);
        winnerPane.setLayout(winnerPaneLayout);
        winnerPaneLayout.setHorizontalGroup(
            winnerPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerPaneLayout.createSequentialGroup()
                .addGap(470, 470, 470)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(399, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, winnerPaneLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(390, 390, 390))
        );
        winnerPaneLayout.setVerticalGroup(
            winnerPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, winnerPaneLayout.createSequentialGroup()
                .addContainerGap(246, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(90, 90, 90)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(185, 185, 185))
        );

        mainPane.add(winnerPane, "card10");

        offMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/off.png"))); // NOI18N
        offMenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        offMenu.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        offMenu.setMinimumSize(new java.awt.Dimension(30, 26));
        offMenu.setPreferredSize(new java.awt.Dimension(30, 26));
        offMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                offMenuMouseClicked(evt);
            }
        });
        jMenuBar1.add(offMenu);

        confMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/config.png"))); // NOI18N
        confMenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        confMenu.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        confMenu.setMinimumSize(new java.awt.Dimension(30, 26));
        confMenu.setPreferredSize(new java.awt.Dimension(30, 26));
        confMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                confMenuMouseClicked(evt);
            }
        });
        jMenuBar1.add(confMenu);

        infoMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/info.png"))); // NOI18N
        infoMenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        infoMenu.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        infoMenu.setMinimumSize(new java.awt.Dimension(30, 26));
        infoMenu.setPreferredSize(new java.awt.Dimension(30, 26));
        infoMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                infoMenuMouseClicked(evt);
            }
        });
        jMenuBar1.add(infoMenu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPane, javax.swing.GroupLayout.PREFERRED_SIZE, 1024, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPane, javax.swing.GroupLayout.PREFERRED_SIZE, 576, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBotActionPerformed
        cardLayout.show(mainPane, "menuPane");
    }//GEN-LAST:event_backBotActionPerformed

    private void clasicBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clasicBotActionPerformed
        cardLayout.show(mainPane, "loserPane");
    }//GEN-LAST:event_clasicBotActionPerformed

    private void batBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_batBotActionPerformed
        try {
            socket = new Socket("localhost",35558);
            salidaDatos = new ObjectOutputStream(socket.getOutputStream());
            salidaDatos.flush();
            entradaDatos = new ObjectInputStream(socket.getInputStream());
            
            //PRUEBAS
            System.out.println("salida y entrada ready");
            enviarMensaje("C_JUEGO",null);
            try{
                Mensaje msj = (Mensaje) entradaDatos.readObject();
                if("RECHAZADO".equals(msj.getTipo())){
                    AudioManager.playSonido("/buscaminas/recursos/audio/info.wav");
                    JOptionPane.showMessageDialog(this, "Lleno, intenta mas tarde");
                    salidaDatos.close();
                    entradaDatos.close();
                    socket.close();
                    return;
                }
            }catch(HeadlessException | IOException | ClassNotFoundException e){
             
            }
            
            escucharMensaje();
            enviarMensaje("NOMBRE",nombre);
            enviarMensaje("CONEXION",null);
            
            // Panel de Loading
            System.out.println("Conectado, mostrando loading...");
            waiting = new LoadingFrame();
            waiting.setVisible(true);
            
            if(oListo==false){
                System.out.println("Buscando jugador");
                
            }
        } catch (IOException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_batBotActionPerformed

    private void jugarBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jugarBotActionPerformed
        cardLayout.show(mainPane, "modePane");
    }//GEN-LAST:event_jugarBotActionPerformed

    private void sigBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sigBotActionPerformed
        if(jugador==1){
            enviarMensaje("TABLERO", tableroStr);
            enviarMensaje("OPCIONES", true);
        }
        cardLayout.show(mainPane, "perPane");
    }//GEN-LAST:event_sigBotActionPerformed

    private void conectarBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_conectarBotActionPerformed
        try {
            nombre = logField.getText().trim();
            cont = contField.getText().trim();
            String[] datos = {nombre,cont};
            if(nombre.isEmpty()||cont.isEmpty()){
                AudioManager.playSonido("/buscaminas/recursos/audio/info.wav");
                JOptionPane.showMessageDialog(this, "Campos vacios");
                return;
            }
            
            socket = new Socket("localhost",35558);
            salidaDatos = new ObjectOutputStream(socket.getOutputStream());
            salidaDatos.flush();
            entradaDatos = new ObjectInputStream(socket.getInputStream());
            
            //PRUEBAS
            System.out.println("salida y entrada ready");
            enviarMensaje("C_LOGIN",datos);
            escucharMensaje();
        } catch (IOException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_conectarBotActionPerformed

    private void ezBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ezBotActionPerformed
        tableroStr = "Principiante";
    }//GEN-LAST:event_ezBotActionPerformed

    private void norBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_norBotActionPerformed
        tableroStr = "Intermedio";
    }//GEN-LAST:event_norBotActionPerformed

    private void hardBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hardBotActionPerformed
        tableroStr = "Avanzado";
    }//GEN-LAST:event_hardBotActionPerformed

    private void salirBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salirBotActionPerformed
       System.exit(0);
    }//GEN-LAST:event_salirBotActionPerformed

    private void jugarBot2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jugarBot2ActionPerformed
        personaje = tarjetaActual;
        enviarMensaje("PERSONAJE", personaje);
        
        if (jugador == 1) {
            jugarBot2.setEnabled(true);
        }
        
        // Solo mostrar loading screen si no está ya mostrandose
        if (waiting == null || !waiting.isVisible()) {
            waiting = new LoadingFrame();
            waiting.setVisible(true);
        }
        
        jugarBot2.setEnabled(false);
        
        enviarMensaje("SELECCION", true);
        
        /*if(jListo==false){
            //System.out.println("Eligiendo personaje");
        }*/
        
        System.out.println("Personaje seleccionado, esperando oponente");
        
    }//GEN-LAST:event_jugarBot2ActionPerformed

    private void flechaIzqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_flechaIzqActionPerformed
        CardLayout cl = (CardLayout) charaSelectPanel.getLayout();
        cl.previous(charaSelectPanel);

        if (tarjetaActual.equals("Roberto")) {
            tarjetaActual = "AntiRoberto";
        } else {
            tarjetaActual = "Roberto";
        }
        
         actualizarInformacionPersonaje();
              
    }//GEN-LAST:event_flechaIzqActionPerformed

    private void flechaDerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_flechaDerActionPerformed
        CardLayout cl = (CardLayout) charaSelectPanel.getLayout();
        cl.next(charaSelectPanel);
        

        // Cambiar valor según el orden
        if (tarjetaActual.equals("Roberto")) {
            tarjetaActual = "AntiRoberto";
        } else {
            tarjetaActual = "Roberto";
        }
        
         actualizarInformacionPersonaje();
              
    }//GEN-LAST:event_flechaDerActionPerformed

    private void topBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_topBotActionPerformed
        try {
            socket = new Socket("localhost",35558);
            salidaDatos = new ObjectOutputStream(socket.getOutputStream());
            salidaDatos.flush();
            entradaDatos = new ObjectInputStream(socket.getInputStream());
            
            //PRUEBAS
            System.out.println("salida y entrada ready");
            enviarMensaje("C_RANKING",null);
            escucharMensaje();
        } catch (IOException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_topBotActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        cardLayout.show(mainPane, "menuPane");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void confMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_confMenuMouseClicked
        new VolumenFrame().setVisible(true);
    }//GEN-LAST:event_confMenuMouseClicked

    private void offMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_offMenuMouseClicked
        dispose();
    }//GEN-LAST:event_offMenuMouseClicked

    private void infoMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_infoMenuMouseClicked
        new About().setVisible(true);
    }//GEN-LAST:event_infoMenuMouseClicked

    private void contFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_contFieldActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        cardLayout.show(mainPane, "menuPane");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        cardLayout.show(mainPane, "menuPane");
    }//GEN-LAST:event_jButton3ActionPerformed

    //tiempo
    public void setCrono(){
        cronoCorre=true;
        seg=0;
        tiempoLabel.setText("000");
        hiloCrono = new Thread(() -> {
            try {
                while(cronoCorre){
                    Thread.sleep(1000);
                    seg++;
                    String tiempo = String.format("%02d",seg);
                    tiempoLabel.setText(tiempo);
                }
            }catch(InterruptedException ex){
                ex.printStackTrace();
            }
        });
        hiloCrono.start();
    }
    public int pararCrono(){
        hiloCrono.interrupt();
        cronoCorre=false;
        return seg;
    }
    
    public void terminarJuego(boolean vivir, int puntos){
        this.puntos=puntos;
        terminar=true;
        enviarMensaje("PUNTOS", puntos);
        enviarMensaje("VIVIR", vivir);
    }
    
    public void perderVida(int vidas){
        AudioManager.playSonido("/buscaminas/recursos/audio/bomb.wav");
        
        sacudirVentana();
        
        this.vidas = vidas;
        ImageIcon lifeIcon = new ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/livesGONE.png"));
        if(vidas==2){
            p1h1.setIcon(lifeIcon);
        }if(vidas==1){
            p1h2.setIcon(lifeIcon);
        }if(vidas==0){
            p1h3.setIcon(lifeIcon);
        }
        enviarMensaje("VIDAS",vidas);
    }
    
    public void escucharMensaje(){
        new Thread(()->{
            try{
                while(true){
                    Object obj = entradaDatos.readObject();
                    Mensaje msj = (Mensaje) obj;
                    System.out.println("Servidor dice:" + msj);
                    decodificar(msj);
                }
            }catch(IOException | ClassNotFoundException e){
                //
            }
        }).start();
    }
    
    public void decodificar(Mensaje msj){
        switch(msj.getTipo()){
            case "INICIO":  if((Boolean) msj.getContenido()){
                                AudioManager.playSonido("/buscaminas/recursos/audio/info.wav");
                                JOptionPane.showMessageDialog(null,"Inicio de sesion exitoso.", "Info", JOptionPane.INFORMATION_MESSAGE);
                                cardLayoutSmall.show(smallPane, "botPane");
                            }else{
                                JOptionPane.showMessageDialog(null,"Contraseña incorrecta.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
            break;
            case "RANKING": List<HistorialPartida> partidas = (List<HistorialPartida>) msj.getContenido();
                            JLabel[] labelsTop = {
                                top1, top2, top3, top4, top5, top6, top7, top8, top9, top10
                            };
                            JLabel[] labelsPoints = {
                                points1, points2, points3, points4, points5, points6, points7, points8, points9, points10
                            };
                            for(int i=0;i<10;i++){
                                if(i<partidas.size()){
                                    labelsTop[i].setText(partidas.get(i).getJugador());
                                    labelsPoints[i].setText(String.valueOf(partidas.get(i).getPuntaje()));
                                }else{
                                    labelsTop[i].setText("---");
                                    labelsPoints[i].setText("---");
                                }
                            }
                            cardLayout.show(mainPane, "rankPane");
            break;
            case "CUENTA":  if((Boolean) msj.getContenido()){
                                AudioManager.playSonido("/buscaminas/recursos/audio/info.wav");
                                JOptionPane.showMessageDialog(null,"Cuenta creada con exito.", "Info", JOptionPane.INFORMATION_MESSAGE);
                                cardLayoutSmall.show(smallPane, "botPane");
                            }
            break;
            case "CONEXION":if((Integer) msj.getContenido()==1){
                                oListo = false;
                                System.out.println("Eres el jugador 1 - Esperando oponente...");
                            }else if((Integer) msj.getContenido()==2){
                                enviarMensaje("NOMBREOP",true);
                                oListo = true;
                                
                                if(jugador==1){
                                    
                                    // Se elimina la ventana de espera una vez que se unen ambos jugadores.
                                    cerrarLoadingFrame();
                                    
                                    cardLayout.show(mainPane, "optionPane");
                                }else if(jugador==2){
                                    System.out.println("Jugador 1 esta eligiendo");
                                }
                            }   
            break;
            case "NOMBRE":  nombreOP = String.valueOf(msj.getContenido());
                            jug1Label.setText(nombre);
                            jug2Label.setText(nombreOP);
            break;
            case "JUGADOR": jugador = ((Integer) msj.getContenido())+1;
                            
            break;
            case "TABLERO": tableroStr = String.valueOf(msj.getContenido());
                            try(InputStream input = getClass().getResourceAsStream("/buscaminas/recursos/tableros.json")){
                                InputStreamReader reader = new InputStreamReader(input);
                                Gson gson = new Gson();
                                TablerosConfig config = gson.fromJson(reader, TablerosConfig.class);
                                tablero = config.buscarPorNombre(tableroStr);
                               
                                filas = tablero.getFilas();
                                columnas = tablero.getColumnas();
                                minas = tablero.getMinas();
                            }catch(Exception e){
                                //
                            }      
            break;
            case "OPCIONES":if((Boolean) msj.getContenido()){
                            if((Boolean) msj.getContenido()){
                                
                            // Cuando el jugador 1 ha elegido dificultad, el jugador 2 cierra el loading
                            if(jugador == 2) {
                                cerrarLoadingFrame();
                                System.out.println("Jugador 1 eligió dificultad, cerrando loading");
                            }
                            
                            cardLayout.show(mainPane, "perPane");
                       }
            }
            break;
            case "OPONENTE": personajeOP = String.valueOf(msj.getContenido());
            break;
            case "SELECCION":if(!(Boolean) msj.getContenido()){
                                jListo = false;
                                System.out.println("Esperando a que el oponente seleccione personaje");
                            }else if((Boolean) msj.getContenido()){
                                jListo = true;
                                
                                // Se elimina la ventana de espera una vez que se unen ambos jugadores.
                                cerrarLoadingFrame();
                                System.out.println("Ambos jugadores seleccionaron personaje. Iniciando juego");
                                
                                board = new GameBoardPanel(this, filas, columnas, minas);
                                cardLayout.show(mainPane, "gamePane");
                                boardPane.setLayout(new BorderLayout());
                                boardPane.add(board, BorderLayout.CENTER);
                                boardPane.revalidate();
                                boardPane.repaint();
                                AudioManager.parar();
                                AudioManager.playMusica("/buscaminas/recursos/audio/battle1.wav");
                            }   
            break;
            case "VIDAS":   vidasOP = (Integer) msj.getContenido();
                            AudioManager.playSonido("/buscaminas/recursos/audio/bombOP.wav");
                            ImageIcon lifeIcon = new ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/livesGONE.png"));
                            if(vidasOP==2){
                                p2h1.setIcon(lifeIcon);
                            }if(vidasOP==1){
                                p2h2.setIcon(lifeIcon);
                            }if(vidasOP==0){
                                p2h3.setIcon(lifeIcon);
                            }
            break;
            case "MORIR": if((Boolean)msj.getContenido()){
                            System.out.println("Jugador OP murio!");
                          }else{
                            System.out.println("Jugador OP termino el tablero!");
                          }
                          terminarOP=true;
                          if(terminar&&terminarOP){
                              enviarMensaje("TERMINAR",true);
                          }
            break;
            case "PUNTOS": puntosOP = (Integer) msj.getContenido();
            break;
            case "TERMINAR":if(puntos>puntosOP){
                                ganador=true;
                            }else{
                                ganador=false;
                            }
                            ArrayList<Object> jugadorDatos = new ArrayList<>(Arrays.asList(nombre, cont, ganador, puntos, seg));                
                            partida = new HistorialPartida(nombre, ganador, puntos, tableroStr, seg, vidas);
                            enviarMensaje("BD_GUARDAR_JUGADOR",jugadorDatos);
                            enviarMensaje("BD_GUARDAR_PARTIDA",partida);

                            cardLayout.show(mainPane, "finishPane");
            break;
        }
    }
    
    public void enviarMensaje(String tipo, Object contenido){
        try{
            Mensaje msj = new Mensaje(tipo, contenido);
            salidaDatos.writeObject(msj);
            salidaDatos.flush();
            System.out.println(msj);
        }catch(IOException e){
            
        }
    }
    
    // Métodos para la la estética de la GUI //
    
    private String obtenerPanelActual() {
    for (Component c : charaSelectPanel.getComponents()) {
        if (c.isVisible()) {
            return ((CardLayout) charaSelectPanel.getLayout()).toString();
        }
    }
        return null;
    }
    
    private void cerrarLoadingFrame() {
        if (waiting != null) {
            SwingUtilities.invokeLater(() -> {
            if (waiting.isVisible()) {
                waiting.dispose();
                System.out.println("LoadingFrame cerrado exitosamente");
            }
                waiting = null;
            });
        }
    }
    
    private void actualizarInformacionPersonaje() {
        if (tarjetaActual.equals("Roberto")) {

            jLabel15.setText("ROBERTO AZUL");

            // Chara 1
            ImageIcon iconoRoberto = new ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/normalMug.png"));
            jLabel13.setIcon(iconoRoberto);
            jTextArea1.setText("Roberto. Un joven guapo y amable, busca ser el mejor en el Buscaminas.");
            jLabel13.setText("");

        } else {

            jLabel15.setText("ANTI ROBERTO");

            // Chara 2
            ImageIcon iconoAntiRoberto = new ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/antiMug.png"));
            jLabel13.setIcon(iconoAntiRoberto);
            jTextArea1.setText("El archienemigo de Roberto. Oscuro y misterioso, busca demostrar su superioridad en el Buscaminas.");
            jLabel13.setText("");
        }
    }
    
    public void sacudirVentana() {
    final int originalX = getLocationOnScreen().x;
    final int originalY = getLocationOnScreen().y;
    final int sacudidas = 10; // Número de sacudidas
    final int desplazamiento = 5; // Píxeles de desplazamiento
    
    new Thread(() -> {
        try {
            for (int i = 0; i < sacudidas; i++) {
                // Calcular posición de sacudida
                int x = originalX + (i % 2 == 0 ? desplazamiento : -desplazamiento);
                int y = originalY + (i % 3 == 0 ? desplazamiento : -desplazamiento);
                
                SwingUtilities.invokeLater(() -> {
                    setLocation(x, y);
            });
                
                Thread.sleep(50); // Velocidad del temblor
            }
            
            // Volver a la posición original
            SwingUtilities.invokeLater(() -> {
                setLocation(originalX, originalY);
            });
            
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        }).start();
    }
    
    ///////////////////////////////////////////////////////////////////////
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

                try {
                    FlatLightLaf.registerCustomDefaultsSource( "Buscaminas.recursos" );
                    UIManager.setLookAndFeel( new FlatLightLaf() );
                } catch( Exception ex ) {
                    System.err.println( "Failed to initialize Look and Feel" );
                }
                
                new Splash().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backBot;
    private javax.swing.JButton batBot;
    private javax.swing.JPanel boardPane;
    private javax.swing.JPanel botPane;
    private javax.swing.JLabel chara1;
    private javax.swing.JPanel chara1Panel;
    private javax.swing.JLabel chara2;
    private javax.swing.JPanel chara2Panel;
    private javax.swing.JPanel charaSelectPanel;
    private javax.swing.JButton clasicBot;
    private javax.swing.JButton conectarBot;
    private javax.swing.JMenu confMenu;
    private javax.swing.JTextField contField;
    private javax.swing.JButton ezBot;
    private javax.swing.JButton flechaDer;
    private javax.swing.JButton flechaIzq;
    private javax.swing.JPanel gamePane;
    private javax.swing.JButton hardBot;
    private javax.swing.JMenu infoMenu;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel jug1Label;
    private javax.swing.JLabel jug2Label;
    private javax.swing.JButton jugarBot;
    private javax.swing.JButton jugarBot2;
    private javax.swing.JTextField logField;
    private javax.swing.JPanel logPane;
    private javax.swing.JPanel loserPane;
    private javax.swing.JPanel mainPane;
    private javax.swing.JPanel menuPane;
    private javax.swing.JPanel modePane;
    private javax.swing.JButton norBot;
    private javax.swing.JMenu offMenu;
    private javax.swing.JPanel optionPane;
    private javax.swing.JLabel p1h1;
    private javax.swing.JLabel p1h2;
    private javax.swing.JLabel p1h3;
    private javax.swing.JLabel p2h1;
    private javax.swing.JLabel p2h2;
    private javax.swing.JLabel p2h3;
    private javax.swing.JPanel perPane;
    private javax.swing.JLabel points1;
    private javax.swing.JLabel points10;
    private javax.swing.JLabel points2;
    private javax.swing.JLabel points3;
    private javax.swing.JLabel points4;
    private javax.swing.JLabel points5;
    private javax.swing.JLabel points6;
    private javax.swing.JLabel points7;
    private javax.swing.JLabel points8;
    private javax.swing.JLabel points9;
    private javax.swing.JPanel rankPane;
    private javax.swing.JButton salirBot;
    private javax.swing.JButton sigBot;
    private javax.swing.JPanel smallPane;
    private javax.swing.JLabel tiempoLabel;
    private javax.swing.JLabel top1;
    private javax.swing.JLabel top10;
    private javax.swing.JLabel top2;
    private javax.swing.JLabel top3;
    private javax.swing.JLabel top4;
    private javax.swing.JLabel top5;
    private javax.swing.JLabel top6;
    private javax.swing.JLabel top7;
    private javax.swing.JLabel top8;
    private javax.swing.JLabel top9;
    private javax.swing.JButton topBot;
    private javax.swing.JPanel waitPane;
    private javax.swing.JPanel winnerPane;
    // End of variables declaration//GEN-END:variables
}
