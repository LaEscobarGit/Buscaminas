package buscaminas.comunes;
import buscaminas.cliente.Menu;
import buscaminas.recursos.audio.AudioManager;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GameBoardPanel extends JPanel {
    Menu menu;
    
    int ROWS;
    int COLS;
    int numMines;
    int vidas = 3;
    int clicks = 0;
    int bvclicks = 0;
    double bvs = 0;
    int puntos = 0;
    
    int seg = 0;
    
    Cell cells[][];
    boolean[][] isMined;
    boolean[][] marcado;
    
    private static final long serialVersionUID = 1L;

    // constantes de ui
    public int CELL_SIZE;
    public final int CANVAS_WIDTH = 424;
    public final int CANVAS_HEIGHT = 424;

    public GameBoardPanel(Menu menu, int ROWS, int COLS, int numMines) {
        this.menu = menu;
        this.ROWS = ROWS;
        this.COLS = COLS;
        this.numMines = numMines;
        cells = new Cell[ROWS][COLS];
        isMined = new boolean[ROWS][COLS];
        //CANVAS_WIDTH = CELL_SIZE * COLS;
        //CANVAS_HEIGHT = CELL_SIZE * ROWS;
        CELL_SIZE = Math.min(CANVAS_WIDTH / COLS, CANVAS_HEIGHT / ROWS);
        
        
        super.setLayout(new GridLayout(ROWS, COLS, 2, 2));
        for (int row = 0; row < ROWS; ++row) {
            for (int col = 0; col < COLS; ++col) {
                cells[row][col] = new Cell(row, col);
                super.add(cells[row][col]);
            }
        }

        // Listener para todos los botones
        MouseListener listener = new MouseListener(){
            @Override
            public void mouseClicked(MouseEvent e){
                Cell cell = (Cell) e.getSource();
                
                if(SwingUtilities.isLeftMouseButton(e)){
                    if(clicks==0){
                        newGame(cell.getRow(),cell.getCol());
                    }
                    revealCell(cell.getRow(),cell.getCol());
                }else if(SwingUtilities.isRightMouseButton (e)){
                    if(cell.isRevealed()==false){
                        AudioManager.playSonido("/buscaminas/recursos/audio/flag.wav");
                        if(cell.isFlagged()==true){
                            cell.setText("");
                            cell.setIcon(null);
                            cell.setFlagged(false);
                        }else{
                            ImageIcon flagIcon = new ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/flagRED.png"));
                            cell.setIcon(flagIcon);
                            cell.setHorizontalAlignment(SwingConstants.CENTER);
                            cell.setText("");
                            cell.setFlagged(true);
                        }
                    }
                }
                clicks++;
            }

            @Override
            public void mousePressed(MouseEvent e) {}
            @Override
            public void mouseReleased(MouseEvent e) {}
            @Override
            public void mouseEntered(MouseEvent e) {}
            @Override
            public void mouseExited(MouseEvent e) {}
        };

        //Dar el listener a todos los botoncitos
        for(int i=0;i<ROWS;i++){
            for(int j=0;j<COLS;j++){
                cells[i][j].addMouseListener(listener);
            }
        }

        super.setPreferredSize(new Dimension(CANVAS_WIDTH, CANVAS_HEIGHT));
   }

    //Inicializa el mapa de minas
    public void newGame(int fRow, int fCol) {
        //Hacer el mapa de minas
        MineMap mineMap = new MineMap(fRow, fCol, ROWS, COLS);
        mineMap.newMineMap(numMines);

        // Resetear todo
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                cells[row][col].newGame(mineMap.isMined[row][col]);
            }
        }
        menu.setCrono();
        calcular3BV();
    }

    //Minas alrededor
    private int getSurroundingMines(int srcRow, int srcCol) { 
        int countMines = 0;
        for (int row = srcRow - 1; row <= srcRow + 1; row++) {
            for (int col = srcCol - 1; col <= srcCol + 1; col++) {
                if (row >= 0 && row < ROWS && col >= 0 && col < COLS) {
                    if (cells[row][col].isMined)
                        countMines++;
                }
            }
        }
        return countMines;
    }

    //Revelar las celdas
    //NOTA: si se revela una que no tiene minas alrededor se revelan todos los de alrededor
    private void revealCell(int srcRow, int srcCol) {
        cells[srcRow][srcCol].setRevealed(true);
        cells[srcRow][srcCol].paint();
        if (cells[srcRow][srcCol].isMined){
            ImageIcon mineIcon = new ImageIcon(getClass().getResource("/buscaminas/recursos/imagenes/mine.png"));
            cells[srcRow][srcCol].setIcon(mineIcon);
            cells[srcRow][srcCol].setHorizontalAlignment(SwingConstants.CENTER);
            cells[srcRow][srcCol].setText("");
            vidas--;
            menu.perderVida(vidas);
            if(vidas==0){
                terminarJuego(false);
            }
        }
        else{
            int countMines = getSurroundingMines(srcRow, srcCol);
            if(countMines!=0){
                cells[srcRow][srcCol].setText(countMines + "");
                AudioManager.playSonido("/buscaminas/recursos/audio/celda1.wav");
            }else{
                cells[srcRow][srcCol].setText("");
            }
            if (countMines == 0) {
                for (int row = srcRow - 1; row <= srcRow + 1; row++) {
                    for (int col = srcCol - 1; col <= srcCol + 1; col++) {
                        if (row >= 0 && row < ROWS && col >= 0 && col < COLS) {
                            if (!cells[row][col].isRevealed)
                                revealCell(row, col);
                        }
                    }
                }
                AudioManager.playSonido("/buscaminas/recursos/audio/celda.wav");
            }
            if(completadoTablero()){
                terminarJuego(true);
            }
        }
    }

    //Verdadero si ha ganado
    public boolean completadoTablero() {
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                if(cells[row][col].isMined()==false){
                    if(cells[row][col].isRevealed()==false){
                        return false;
                    }
                }
            }
        }
        return true;
    }
    
    public void terminarJuego(boolean vivir) {
        seg = menu.pararCrono();
        calcularPuntaje();
        menu.terminarJuego(vivir, puntos);
    }

    public void calcular3BV(){
        marcado = new boolean[ROWS][COLS];
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                if(!cells[row][col].isMined() && !marcado[row][col]){
                    if(getSurroundingMines(row,col)==0){
                        marcado[row][col] = true;
                        flood(row,col);
                        bvclicks++;
                    }
                    if(!alrededorCero(row,col)){
                        marcado[row][col] = true;
                        bvclicks++;
                    }
                }
            }
        }
    }
    
    public void flood(int row, int col){
        for(int r=row-1 ; r<=row+1 ; r++){
            for(int c=col-1 ; c<=col+1 ; c++){
                if (r >= 0 && r < ROWS && c >= 0 && c < COLS) {
                    if(!cells[r][c].isMined() && !marcado[r][c]){
                        marcado[r][c] = true;
                        if(getSurroundingMines(r,c)==0){
                            flood(r,c);
                        }
                    }
                }
            }
        }
    }
    
    public boolean alrededorCero(int row, int col){
        for(int r=row-1 ; r<=row+1 ; r++){
            for(int c=col-1 ; c<=col+1 ; c++){
                if (r >= 0 && r < ROWS && c >= 0 && c < COLS) {
                    if(getSurroundingMines(r,c)==0){
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public void calcularPuntaje(){
        bvs = (double)bvclicks/(double)seg;
        puntos = (int)Math.ceil(bvs*1000);
        if(vidas==2){
            puntos = (int)Math.ceil(puntos*0.95);
        }else if(vidas==1){
            puntos = (int)Math.ceil(puntos*0.85);
        }else if(vidas==0){
            puntos = (int)Math.ceil(puntos*0.50);
        }
    }
}