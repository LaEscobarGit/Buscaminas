package buscaminas.servidor;

import buscaminas.comunes.BaseDatosBuscaminas;
import buscaminas.comunes.JugadorStats;
import buscaminas.comunes.Mensaje;
import buscaminas.comunes.HistorialPartida;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class ManejoCliente extends Thread{
    List<ObjectOutputStream> clientes = new ArrayList<>();
    BaseDatosBuscaminas bdb;
    Socket cliente;
    ObjectInputStream entradaDatos;
    ObjectOutputStream salidaDatos;
    int noJugador;
    static String[] personajes = new String[2];
    static String[] nombres = new String[2];
    static boolean[] vivir = new boolean[2];
    String[] datos;
    
    public ManejoCliente(List<ObjectOutputStream> clientes, Socket cliente, ObjectInputStream entradaDatos, ObjectOutputStream salidaDatos, int noJugador, BaseDatosBuscaminas bdb){
        this.clientes = clientes;
        this.cliente = cliente;
        this.entradaDatos = entradaDatos;
        this.salidaDatos = salidaDatos;
        this.noJugador = noJugador;
        this.bdb = bdb;
    }
    
    @Override
    public void run(){
        try{
            while(true){
                Object recibido = entradaDatos.readObject();
                Mensaje msj = (Mensaje) recibido;
                decodificar(msj);
            }
        }catch(IOException | ClassNotFoundException e){
            desconectar();
        }
    }
    
    public void enviarMensajeGrupal(Mensaje msj){
        for(ObjectOutputStream c: clientes){
            try{
                c.writeObject(msj);
            }catch(IOException e){
                //
            }
        }
    }
    
    public void enviarMensaje(Mensaje msj){
        try {
            salidaDatos.writeObject(msj);
        } catch (IOException ex) {
            Logger.getLogger(ManejoCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void enviarMensajeOpuesto(Mensaje msj){
        try{
            if(noJugador==0){
                clientes.get(1).writeObject(msj);
            }else if(noJugador==1){
                clientes.get(0).writeObject(msj);
            }
        }catch (IOException ex){
            Logger.getLogger(ManejoCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void decodificar(Mensaje msj){
        switch(msj.getTipo()){
            case "BD_GUARDAR_JUGADOR":  ArrayList<Object> datosJugador = (ArrayList<Object>) msj.getContenido();
                                        String nombre = (String) datosJugador.get(0);
                                        String cont = (String) datosJugador.get(1);
                                        boolean ganador = (Boolean) datosJugador.get(2);
                                        int puntos = (Integer) datosJugador.get(3);
                                        int seg = (Integer) datosJugador.get(4);
                                        bdb.guardarJugador(nombre, cont, ganador, puntos, seg);
            break;
            case "BD_GUARDAR_PARTIDA":  HistorialPartida partida = (HistorialPartida) msj.getContenido();
                                        bdb.guardarPartida(partida);
            break;
            case "CONEXION":enviarMensajeGrupal(new Mensaje("CONEXION", clientes.size()));
                            System.out.println(clientes.size());
            break;
            case "NOMBRE": nombres[noJugador]= String.valueOf(msj.getContenido());
                            System.out.println(msj.getContenido());
            break;
            case "NOMBREOP":try {
                                clientes.get(0).writeObject(new Mensaje("NOMBRE", nombres[1]));
                                clientes.get(1).writeObject(new Mensaje("NOMBRE", nombres[0]));
                            } catch (IOException ex) {
                                Logger.getLogger(ManejoCliente.class.getName()).log(Level.SEVERE, null, ex);
                            }
            break;
            case "TABLERO": enviarMensajeGrupal(new Mensaje("TABLERO", msj.getContenido()));
                            System.out.println(msj.getContenido());
            break;
            case "OPCIONES":enviarMensajeGrupal(new Mensaje("OPCIONES", msj.getContenido()));
                            System.out.println(msj.getContenido());
            break;
            case "PERSONAJE":personajes[noJugador]= String.valueOf(msj.getContenido());
                            System.out.println(msj.getContenido());
            break;
            case "SELECCION":boolean lleno = false;
                            for(int i=0; i<personajes.length;i++){
                                if(personajes[i]==null){
                                    lleno=false;
                                    break;
                                }else{
                                    lleno=true;
                                }
                            }
                            if(lleno){
                                System.out.println(personajes[0]);
                                System.out.println(personajes[1]);
                                try {
                                    clientes.get(0).writeObject(new Mensaje("OPONENTE", personajes[1]));
                                    clientes.get(1).writeObject(new Mensaje("OPONENTE", personajes[0]));
                                    enviarMensajeGrupal(new Mensaje("SELECCION", lleno));
                                } catch (IOException ex) {
                                    Logger.getLogger(ManejoCliente.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }      
            break;
            case "INICIAR": 
            break;
            case "VIDAS": enviarMensajeOpuesto(new Mensaje("VIDAS",msj.getContenido()));
            break;
            case "VIVIR":   vivir[noJugador]= (Boolean) msj.getContenido();
                            System.out.println(msj.getContenido());
                            if(vivir[noJugador]){
                                enviarMensajeOpuesto(new Mensaje("MORIR",false));
                            }else{
                                enviarMensajeOpuesto(new Mensaje("MORIR",true));
                            }             
            break;
            case "PUNTOS": enviarMensajeOpuesto(new Mensaje("PUNTOS",(Integer)msj.getContenido()));
            break;
            case "TERMINAR": enviarMensajeGrupal(new Mensaje("TERMINAR",true));
            break;
            case "EXIT":try{
                            entradaDatos.close();
                            salidaDatos.close();
                            cliente.close();
                            clientes.remove(salidaDatos);
                        }catch (IOException ex) {
                            Logger.getLogger(ManejoCliente.class.getName()).log(Level.SEVERE, null, ex);
                        }
            break;
        }
    }
    
    public void desconectar(){
        System.out.println("Cliente desconectado");
        enviarMensajeOpuesto(new Mensaje("DESCONECTADO",true));
        try{
            entradaDatos.close();
            salidaDatos.close();
            cliente.close();
            clientes.remove(salidaDatos);
        }catch (IOException ex) {
            Logger.getLogger(ManejoCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
